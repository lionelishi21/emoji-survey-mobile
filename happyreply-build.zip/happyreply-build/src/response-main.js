
// Main important
import './assets/css/flexboxgrid.min.css'
import './assets/sass/survey-response.scss'

// library auto imports
import 'es6-promise/auto'