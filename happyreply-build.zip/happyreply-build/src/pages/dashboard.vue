<template>
	<div class="">
	<h1>Dashboard</h1>
	</div>
</template>
<script>
	
</script>