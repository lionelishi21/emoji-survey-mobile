
<template>
<div>
<f7-navbar>
      <f7-nav-left>
        <f7-link>Home</f7-link>
      </f7-nav-left>
      <!-- <f7-nav-center>Home</f7-nav-center> -->
      <f7-nav-right>
        <f7-link>
              <i class="icon icon-bars"></i>
        </f7-link>
      </f7-nav-right>
 </f7-navbar>
 </div>
</template>
<script>
    
</script>